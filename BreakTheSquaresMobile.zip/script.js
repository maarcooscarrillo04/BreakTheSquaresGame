const gameArea = document.getElementById('game-area');
const ball = document.getElementById('ball');
const squareCountSpan = document.getElementById('square-count');
const startBtn = document.getElementById('start-btn');

let squares = [];
let ballSpeed = 5;
let level = 1;

function createSquares(level) {
    const squareCount = level * 5;
    squares = [];
    for (let i = 0; i < squareCount; i++) {
        const square = document.createElement('div');
        square.classList.add('square');
        square.style.top = `${Math.random() * (gameArea.clientHeight - 40)}px`;
        square.style.left = `${Math.random() * (gameArea.clientWidth - 40)}px`;
        gameArea.appendChild(square);
        squares.push(square);
    }
    squareCountSpan.textContent = squareCount;
}

function moveBallTouch(e) {
    let touch = e.touches[0];
    let gameAreaRect = gameArea.getBoundingClientRect();

    let newX = touch.clientX - gameAreaRect.left - ball.clientWidth / 2;
    let newY = touch.clientY - gameAreaRect.top - ball.clientHeight / 2;

    // Check boundaries
    if (newX >= 0 && newX <= gameAreaRect.width - ball.clientWidth) {
        ball.style.left = `${newX}px`;
    }
    if (newY >= 0 && newY <= gameAreaRect.height - ball.clientHeight) {
        ball.style.top = `${newY}px`;
    }

    // Check collision with squares
    squares.forEach((square, index) => {
        if (isCollision(ball, square)) {
            gameArea.removeChild(square);
            squares.splice(index, 1);
            squareCountSpan.textContent = squares.length;
            if (squares.length === 0) {
                level++;
                createSquares(level);
            }
        }
    });
}

function isCollision(ball, square) {
    let ballRect = ball.getBoundingClientRect();
    let squareRect = square.getBoundingClientRect();

    return !(
        ballRect.top > squareRect.bottom ||
        ballRect.bottom < squareRect.top ||
        ballRect.left > squareRect.right ||
        ballRect.right < squareRect.left
    );
}

function startGame() {
    level = 1;
    createSquares(level);
    gameArea.addEventListener('touchmove', moveBallTouch);
}

startBtn.addEventListener('click', startGame);
